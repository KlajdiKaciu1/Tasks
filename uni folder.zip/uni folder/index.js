const express = require('express');
const app = express();

app.get('/test',(req,res)=>{
   res.json('test ok')
});
// Login Route
app.post('/login', async (req, res) => {
   const { email, password } = req.body;
   try {
       const userDoc = await User.findOne({ email });
       if (!userDoc) {
           return res.status(400).json({ message: 'Invalid credentials' });
       }
       const isMatch = await bcrypt.compare(password, userDoc.password);
       if (isMatch) {
         jwt.sign({   
           email:userDoc.email,
           id:userDoc._id,
           role: userDoc.role
         }, jwtSecret, {}, (err,token) => {
           if (err) throw err;
           res.cookie('token', token).json(userDoc);
         });
       } else {
         res.status(401).json('Invalid password');
       }
   } catch (error) {
       console.error("Error during login:", error);
       res.status(500).json({ message: 'Internal server error' });
   }
});


app.listen(3000);